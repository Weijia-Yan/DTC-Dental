# DTC-Dental
DTC Dental Project
This is the master repo for our DTC Dental Semester Project. The purpose of this project is to create a fully functional, data driven ASP.NET Core MVC web app for a fictitious
company, named DTC Dental, that allows for scheduling appointments and keeping track of prior completed appointments and what services were completed by a dentist on a specific
patient.
